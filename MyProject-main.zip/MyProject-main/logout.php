<?php 

include 'fungsi.php';

logout();
?>